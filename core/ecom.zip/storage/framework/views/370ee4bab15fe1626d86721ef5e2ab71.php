<?php
    if ($limit) {
        $parentCategories = $parentCategories->take($limit);
    }
?>

<div class="left-site-category active">
    <div class="category-dropdown">
        <ul class="list-inline mega-menu vertical-megamenu">
            <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="fluid-menu <?php echo e($category->allSubcategories->count() && !multiLayerCategory($category) ? 'dropdown  has-submenu' : ''); ?>">
                    <a href="<?php echo e($category->shopLink()); ?>" class="nav-link menu-item <?php if($category->allSubcategories->count()): ?> dropdown has-submenu <?php endif; ?>">
                        <?php if($category->icon): ?>
                            <span class="menu-item-icon">
                                <?php if(preg_match('/^la[sb] /', $category->icon) || preg_match('/^fa[sb] /', $category->icon)): ?>
                                    <i class="<?php echo e($category->icon); ?>"></i>
                                <?php else: ?>
                                    <img src="<?php echo e($category->categoryIcon()); ?>" alt="icon">
                                <?php endif; ?>
                            </span>
                        <?php endif; ?>
                        <?php echo e(__($category->name)); ?>


                        <span class="menu-item-arrowicon">
                            <i class="las la-angle-right"></i>
                        </span>
                    </a>

                    <?php if($category->allSubcategories->count()): ?>
                        <?php if(multiLayerCategory($category)): ?>
                            <ul class="list-inline categories__mega-menu-wrap categories__mega-menu d-none d-lg-block">
                                <li>
                                    <div class="categories__mega-menu-content">
                                        <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="categories__mega-menu-list">
                                                <h5 class="categories__mega-menu-title">
                                                    <a href="<?php echo e($subcategory->shopLink()); ?>"><?php echo e(__($subcategory->name)); ?></a>
                                                </h5>

                                                <?php if($subcategory->allSubcategories): ?>
                                                    <ul class="list-inline cate__mega-menu-list">
                                                        <?php $__currentLoopData = $subcategory->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a href="<?php echo e($subCat->shopLink()); ?>"><?php echo e(__($subCat->name)); ?></a>
                                                                <?php if($subCat->allSubcategories): ?>
                                                                    <ul class="categories__mega-submenu">
                                                                        <?php $__currentLoopData = $subCat->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php echo $__env->make('Template::partials.subcategory_list', [
                                                                                'childCategory' => $childCategory,
                                                                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </ul>
                                                                <?php endif; ?>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                            </ul>
                        <?php else: ?>
                            <ul class="list-inline sub-menu">
                                <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e($subCat->shopLink()); ?>"><?php echo e(__($subCat->name)); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/left_category_menu.blade.php ENDPATH**/ ?>