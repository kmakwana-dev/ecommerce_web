<?php if(gs('subscriber_module')): ?>
    <?php
        $newsletter = getContent('newsletter.content', true);
    ?>

    <div class="newsletter-widget text-center">
        <div class="newsletter-widget-header">
            <h6 class="title"><?php echo e(__($newsletter->data_values->heading)); ?></h6>
            <p class="fs-14"><?php echo e(__($newsletter->data_values->description)); ?></p>
        </div>
        <form action="#" class="subscribe-form" method="POST">
            <input type="email" placeholder="<?php echo app('translator')->get('Your Email Address'); ?>..." name="email">
            <button type="submit" class="subscribe-btn"><span><?php echo app('translator')->get('Subscribe'); ?></span> <i class="las la-paper-plane"></i></button>
        </form>
    </div>

    <?php $__env->startPush('script'); ?>
        <script>
            'use strict';
            (function($) {
                $(document).on('submit', '.subscribe-form', function(e) {
                    e.preventDefault();

                    let data = {
                        email: $('input[name="email"]').val(),
                        _token: `<?php echo e(csrf_token()); ?>`,
                    };

                    if (!data.email) {
                        notify('error', `<?php echo app('translator')->get('The email field is required'); ?>`);
                        return false;
                    }

                    $.post("<?php echo e(route('subscribe')); ?>", data,
                        function(response) {
                            $('.subscribe-btn').removeAttr('disabled');
                            if (response.status) {
                                notify('success', response.message);
                            } else {
                                notify('error', response.message);
                            }

                            $('[name=email]').val('');
                        },
                    );
                });
            })
            (jQuery)
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/newsletter.blade.php ENDPATH**/ ?>