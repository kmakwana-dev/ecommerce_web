<?php
    $headerTwo = App\Models\Frontend::where('data_keys', 'header_two.content')->first()?->data_values;
    $headerTwoKeys = array_keys((array) $headerTwo->group);
    $firstLetters = array_map(function ($key) {
        return $key[0];
    }, $headerTwoKeys);

    $headerTwoLayoutClass = 'middle-menu-' . implode('', $firstLetters);
?>

<?php if(@$headerTwo->status == 'on'): ?>
    <div class="header-middle">
        <div class="container">
            <div class="d-flex justify-content-between header-wrapper <?php echo e($headerTwoLayoutClass); ?>">
                <?php $__currentLoopData = $headerTwo->group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == 'logo_widget' && isset($group->status) && $group->status == 'on'): ?>
                        <?php if (isset($component)) { $__componentOriginal0e3e854f1972cb532cc8b5bc0ace80b0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0e3e854f1972cb532cc8b5bc0ace80b0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-logo','data' => ['type' => 'dark']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'dark']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0e3e854f1972cb532cc8b5bc0ace80b0)): ?>
<?php $attributes = $__attributesOriginal0e3e854f1972cb532cc8b5bc0ace80b0; ?>
<?php unset($__attributesOriginal0e3e854f1972cb532cc8b5bc0ace80b0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0e3e854f1972cb532cc8b5bc0ace80b0)): ?>
<?php $component = $__componentOriginal0e3e854f1972cb532cc8b5bc0ace80b0; ?>
<?php unset($__componentOriginal0e3e854f1972cb532cc8b5bc0ace80b0); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <?php if($key == 'search_widget' && isset($group->status) && $group->status == 'on'): ?>
                        <div class="header-search-wrapper">
                            <form action="<?php echo e(route('product.all')); ?>" method="GET" class="header-search-form me-auto <?php if(!request()->routeIs('home')): ?> w-100 <?php endif; ?>">
                                <div class="header-form-group">
                                    <button type="button" class="search-close-btn"><i class="las la-arrow-up"></i></button>
                                    <input type="text" class="form--control" name="search" value="<?php echo e(request()->search); ?>" placeholder="<?php echo app('translator')->get('I am shopping for'); ?>...">
                                </div>
                                <button class="icon" type="submit"><i class="las la-search"></i></button>
                            </form>
                        </div>
                        <button type="button" class="header-search-btn"><i class="las la-search"></i></button>
                    <?php endif; ?>
                    <?php if($key == 'widgets'): ?>
                        <?php
                            $widgets = collect($group)->where('status', 'on');
                        ?>

                        <?php if($widgets->count()): ?>
                            <ul class="list list--row option-list-wrapper justify-content-center justify-content-md-end option-list d-flex align-items-center">
                                <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(gs('product_compare') && $widget->key == 'compare' && @$widget->status == 'on'): ?>
                                        <li class="d-none d-lg-block">
                                            <a href="<?php echo e(route('compare.all')); ?>" class="ecommerce">
                                                <span class="ecommerce__icon">
                                                    <i class="las la-exchange-alt"></i>
                                                    <span class="ecommerce__is compare-count d-none"></span>
                                                </span>
                                                <span class="ecommerce__text"><?php echo app('translator')->get('Compare'); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if(gs('product_wishlist') && $widget->key == 'wishlist' && @$widget->status == 'on'): ?>
                                        <li class="d-none d-lg-block">
                                            <a href="javascript:void(0)" class="ecommerce wish-button">
                                                <span class="ecommerce__icon">
                                                    <i class="las la-heart"></i>
                                                    <span class="ecommerce__is wishlist-count d-none"></span>
                                                </span>
                                                <span class="ecommerce__text"><?php echo app('translator')->get('Wishlist'); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($widget->key == 'cart' && @$widget->status == 'on'): ?>
                                        <li>
                                            <a href="javascript:void(0)" class="ecommerce cart-button">
                                                <span class="ecommerce__icon">
                                                    <i class="las la-shopping-bag"></i>
                                                    <span class="ecommerce__is cartItemCount d-none"></span>
                                                </span>
                                                <span class="ecommerce__text"><?php echo app('translator')->get('Cart'); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($widget->key == 'notifications' && @$widget->status == 'on'): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <li>
                                                <?php if (isset($component)) { $__componentOriginalcd27c9b38e54bac77bc581449ce10798 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd27c9b38e54bac77bc581449ce10798 = $attributes; } ?>
<?php $component = App\View\Components\UserNotificationComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-notification-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\UserNotificationComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd27c9b38e54bac77bc581449ce10798)): ?>
<?php $attributes = $__attributesOriginalcd27c9b38e54bac77bc581449ce10798; ?>
<?php unset($__attributesOriginalcd27c9b38e54bac77bc581449ce10798); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd27c9b38e54bac77bc581449ce10798)): ?>
<?php $component = $__componentOriginalcd27c9b38e54bac77bc581449ce10798; ?>
<?php unset($__componentOriginalcd27c9b38e54bac77bc581449ce10798); ?>
<?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($widget->key == 'user_auth' && @$widget->status == 'on'): ?>
                                        <li class="d-none d-lg-block">
                                            <?php echo $__env->make('Template::partials.user_auth_options', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($widget->key == 'language' && @$widget->status == 'on'): ?>
                                        <li class="d-none d-lg-block">
                                            <?php echo $__env->make('Template::partials.menu.language_menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->startPush('style'); ?>
    <style>
        @media (min-width: 992px) {
           .header-wrapper .logo img  {
                width: 85% !important;
            }
        }
    </style>
<?php $__env->stopPush(); ?>



<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/headers/header_two.blade.php ENDPATH**/ ?>