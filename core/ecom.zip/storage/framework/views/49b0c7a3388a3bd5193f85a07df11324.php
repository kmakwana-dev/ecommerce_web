<div class="predefined-widgets d-flex gap-2 align-items-center py-2">
    <?php if($headerOne->language_option == 'on'): ?>
        <div class="d-none d-lg-block">
            <?php echo $__env->make('Template::partials.menu.language_menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endif; ?>


    <?php if($headerOne->user_option == 'on'): ?>
        <?php echo $__env->make('Template::partials.user_auth_options', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/header_top_predefined_options.blade.php ENDPATH**/ ?>