<div class="modal custom--modal fade" id="loginAndGuestModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close modal-close-btn" data-bs-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
                <div class="mt-3">
                    <ul class="nav nav-tabs user-tab" id="loginGuestTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login" type="button" role="tab" aria-controls="login" aria-selected="true">
                                <?php echo app('translator')->get('Login'); ?>
                            </button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="guest-tab" data-bs-toggle="tab" data-bs-target="#guest" type="button" role="tab" aria-controls="guest" aria-selected="false">
                                <?php echo app('translator')->get('Guest Checkout'); ?>
                            </button>
                        </li>
                    </ul>
                </div>
                <div class="tab-content" id="loginGuestTabContent">
                    <div class="tab-pane fade show active" id="login" role="tabpanel" aria-labelledby="login-tab">
                        <?php echo $__env->make('Template::partials.login', ['idPrefix' => 'auth-user'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <?php
                        $guestUser = session('guest_user_data');

                        if ($guestUser && $guestUser->country_code) {
                            $mobileCode = $guestUser->country_code;
                        } else {
                            $info = json_decode(json_encode(getIpInfo()), true);
                            $mobileCode = implode(',', $info['code'] ?? []);
                        }
                        $countries = getCountries();
                        $checkoutContent = getContent('guest_checkout.content', true)?->data_values;
                    ?>

                    <div class="tab-pane fade" id="guest" role="tabpanel" aria-labelledby="guest-tab">

                        <?php if(@$checkoutContent->description_in_checkout_form): ?>
                            <p class="my-3">
                                <span class=""><i class="fa-solid fa-circle-info icon"></i></span>
                                <span class="text"><?php echo e(@$checkoutContent->description_in_checkout_form); ?></span>
                            </p>
                        <?php endif; ?>

                        <form action="<?php echo e(route('checkout.guest.info.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="guest-email"><?php echo app('translator')->get('Email'); ?></label>
                                <input type="text" value="<?php echo e(@$guestUser->email); ?>" class="form-control form--control" id="guest-email" name="email" required>
                            </div>

                            <input type="hidden" name="mobile_code">
                            <input type="hidden" name="country_code">

                            <div class="form-group">
                                <label for="guest-mobile"><?php echo app('translator')->get('Mobile'); ?></label>
                                <div class="input-group">
                                    <select name="country" class="input-group-text" required>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" data-code="<?php echo e($key); ?>">+<?php echo e(__($country->dial_code)); ?>(<?php echo e($country->country); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="number" name="mobile" value="<?php echo e(@$guestUser->mobile); ?>" class="form-control form--control ps-0" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn--base w-100 h-45"><?php echo app('translator')->get('Proceed as Guest'); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/global/js/select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        (function($) {
            const formatSelection = (state) => {
                if (!state.id) {
                    return state.text;
                }
                return `+${state.element.dataset.mobile_code}`;
            }

            <?php if($mobileCode): ?>
                const selectedCountry = $(`[data-code=<?php echo e($mobileCode); ?>]`).val();
            <?php else: ?>
                const selectedCountry = $('select[name=country] option').first().val();
            <?php endif; ?>

            $('#loginAndGuestModal select[name=country]').val(selectedCountry).select2({
                dropdownParent: $('#loginAndGuestModal select[name=country]').parent(),
                templateSelection: formatSelection
            });

            $('#loginAndGuestModal select[name=country]').on('change', function() {
                $('input[name=mobile_code]').val($('select[name=country] :selected').last().data('mobile_code'));
                $('input[name=country_code]').val($('select[name=country] :selected').last().data('code'));
                $('.mobile-code').text('+' + $('select[name=country] :selected').last().data('mobile_code'));
            });

            $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
            $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
            $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/guest_user_info.blade.php ENDPATH**/ ?>