 <?php
     $headers = App\Models\Frontend::where('data_keys', 'headers.order.content')->first()->data_values;
     $headerThree = App\Models\Frontend::where('data_keys', 'header_three.content')->first()?->data_values;
     $siteMenu = $headerThree->group->links;
 ?>


 <div class="header-area bg-white">
     <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->make('Template::partials.headers.'.$header, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>

 <?php echo $__env->make('Template::partials.mobile_menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/header.blade.php ENDPATH**/ ?>