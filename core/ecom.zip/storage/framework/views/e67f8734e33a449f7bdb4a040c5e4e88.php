<?php
    $footer = getContent('footer.content', true);
    $footer = @$footer->data_values;
    $socials = getContent('social_icon.element', orderById: true);
    $menus = \App\Models\Frontend::where('data_keys', 'footer_menu.content')->first()->data_values;

?>

<!-- Footer Section Starts Here -->
<footer class="footer-area footer-bg ">
    <div class="container">
        <?php if(
            @$footer->logo ||
                @$footer->footer_note ||
                gs('subscriber_module') == Status::YES ||
                @$footer->contact_address ||
                @$footer->cell_number ||
                @$footer->email): ?>
            <div class="footer-top">
                <div class="footer-widget widget-about">
                    <?php if(@$footer->logo): ?>
                        <img src="<?php echo e(getImage(null)); ?>"
                            data-src="<?php echo e(getImage('assets/images/frontend/footer/' . @$footer->logo)); ?>"
                            class="lazyload footer-logo" alt="footer-logo">
                    <?php endif; ?>

                    <?php if(@$footer->footer_note): ?>
                        <p class="mb-0"><?php echo e(__($footer->footer_note)); ?></p>
                    <?php endif; ?>
                </div>

                <?php echo $__env->make('Template::partials.newsletter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php if(@$footer->contact_address || @$footer->cell_number || @$footer->email): ?>
                    <div class="widget-contact">
                        <?php if(@$footer->contact_heading): ?>
                            <h6 class="title"><?php echo e(__(@$footer->contact_heading)); ?></h6>
                        <?php endif; ?>
                        <ul>
                            <?php if($footer->contact_address): ?>
                                <li>
                                    <i class="las la-map-marker"></i> <?php echo e(__(@$footer->contact_address)); ?>

                                </li>
                            <?php endif; ?>

                            <?php if(@$footer->cell_number): ?>
                                <li>
                                    <a href="tel:<?php echo e(@$footer->cell_number); ?>"><i
                                            class="las la-phone"></i><?php echo e(@$footer->cell_number); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if(@$footer->email): ?>
                                <li>
                                    <a href="mailto:<?php echo e(@$footer->email); ?>"><i
                                            class="las la-envelope"></i><?php echo e(@$footer->email); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if($menus): ?>
            <div class="footer-middle">
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="footer-widget widget-link">
                        <h6 class="title"><?php echo e(__($menu->title)); ?></h6>
                        <ul>
                            <?php $__currentLoopData = $menu->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url($link->url)); ?>"><?php echo e(__($link->name)); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        
        <div class="footer-legal-bar" style="border-top: 1px solid rgba(255,255,255,0.08); padding: 10px 0; margin-top: 4px;">
            <div class="d-flex flex-wrap justify-content-center align-items-center gap-2" style="font-size: 12px; color: rgba(255,255,255,0.55); letter-spacing: 0.3px;">
                <span><strong style="color:rgba(255,255,255,0.75)">GSTIN:</strong> 10AAECW1795M1Z2</span>
                <span style="color:rgba(255,255,255,0.25)">|</span>
                <span><strong style="color:rgba(255,255,255,0.75)">PAN:</strong> AAECW1795M</span>
                <span style="color:rgba(255,255,255,0.25)">|</span>
                <span><strong style="color:rgba(255,255,255,0.75)">CIN:</strong> U62099BR2025PTC077443</span>
            </div>
        </div>

        <?php if(@$footer->copyright_text || $socials->count() > 0 || @$footer->payment_methods): ?>
            <div class="footer-copyright">
                <div
                    class="copyright-area d-flex flex-wrap align-items-center <?php if($socials->count() == 0 && !@$footer->payment_methods): ?> justify-content-center <?php else: ?> justify-content-between <?php endif; ?> gap-4 flex-wrap-reverse">

                    <?php if(@$footer->copyright_text): ?>
                        <div class="left">
                            <?php
                                $copyrightText = str_replace('{year}', date('Y'), $footer->copyright_text);
                                $siteName = '<a href="' . route('home') . '" style="color: white !important;">' . e(gs('site_name')) . '</a>';
                                $copyrightText = str_replace('{site_name}', $siteName, $copyrightText);
                            ?>
                            <p style="color: white !important;"><?php echo __(@$copyrightText); ?></p>
                        </div>
                    <?php endif; ?>


                    <?php if($socials->count() > 0): ?>
                        <ul class="social-icons d-flex gap-2 flex-wrap mt-0">
                            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e($item->data_values->url); ?>" target="_blank">
                                        <?php
                                            echo $item->data_values->social_icon;
                                        ?>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <?php if(@$footer->payment_methods): ?>
                        <div class="right">
                            <img src="<?php echo e(getImage(null)); ?>"
                                data-src="<?php echo e(getImage('assets/images/frontend/footer/' . @$footer->payment_methods, '250x30')); ?>"
                                class="lazyload" alt="<?php echo app('translator')->get('footer'); ?>">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</footer>
<!-- Footer Section Ends Here -->

<div class="modal fade" id="quickView">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <button type="button" class="close modal-close-btn " data-bs-dismiss="modal" aria-label="Close">
                <i class="las la-times"></i>
            </button>
            <div class="modal-body">
                <div class="ajax-loader-wrapper d-flex align-items-center justify-content-center">
                    <div class="spinner-border" role="status">
                        <span class="sr-only"><?php echo app('translator')->get('Loading'); ?>...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>