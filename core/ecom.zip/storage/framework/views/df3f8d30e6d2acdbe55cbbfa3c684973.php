<a href="<?php echo e($category->shopLink()); ?>" class="d-block text-center">
    <img src="<?php echo e(getImage(null)); ?>" data-src="<?php echo e($category->categoryImage()); ?>" class="w-100 lazyload owl-lazy" alt="category">
    <span class="title line-limitation-1"><?php echo e(__($category->name)); ?></span>
</a>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/components/frontend/basic/category-card.blade.php ENDPATH**/ ?>