<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>" itemscope itemtype="http://schema.org/WebPage">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> <?php echo e(gs()->siteName(__($pageTitle))); ?></title>
    <?php echo $__env->make('partials.seo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <link type="image/x-icon" href="<?php echo e(siteFavicon()); ?>" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/line-awesome.min.css')); ?>">
    <?php echo $__env->yieldPushContent('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true) . 'css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true) . 'css/color.php?color=' . gs('base_color'))); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>
    <link href="<?php echo e(asset(activeTemplate(true) . 'css/custom.css')); ?>" rel="stylesheet">
</head>

<?php echo loadExtension('google-analytics') ?>

<body>
    <div class="body-overlay" id="body-overlay"></div>
    <?php echo $__env->make('Template::partials.preloader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('app'); ?>

    <?php echo $__env->yieldPushContent('modal'); ?>

    <script src="<?php echo e(asset('assets/global/js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/global/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/jquery.validate.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script-lib'); ?>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/main.js')); ?>"></script>
    <?php echo loadExtension('tawk-chat') ?>
    <?php echo $__env->make('partials.notify', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if(gs('pn')): ?>
        <?php echo $__env->make('partials.push_script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/layouts/app.blade.php ENDPATH**/ ?>