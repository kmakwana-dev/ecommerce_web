<?php
    $content = getContent('banner.content', true);
?>

<div class="container banner-container <?php if(gs('homepage_layout') == 'full_width_banner'): ?> single-banner <?php endif; ?>">
    <div class="hero-section mb-60">
        <?php if(gs('homepage_layout') == 'sidebar_menu'): ?>
            <?php echo $__env->make('Template::partials.left_category_menu', ['limit' => 13], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <div class="hero-slider">
            <?php echo $__env->make('Template::partials.banner_sliders', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('Template::partials.banner_categories', ['fixedBanner' => $content->data_values?->fixed_banner], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <?php if(gs('homepage_layout') == 'sidebar_menu' && @$content->data_values->fixed_banner): ?>
            <div class="hero-banner">
                <a href="<?php echo e(@$content->data_values->fixed_banner_link); ?>" class="d-inline"><img class="w-100 h-100" src="<?php echo e(frontendImage('banner', @$content->data_values->fixed_banner, '300x510')); ?>" alt=""></a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('style-lib'); ?>
   <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true). 'css/banner.css')); ?>">
<?php $__env->stopPush(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/sections/banner.blade.php ENDPATH**/ ?>