<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'product' => $product,
    'wishlist' => null,
    'showRating' => true,
    'showTitle' => true,
    'showCartButton' => true,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'product' => $product,
    'wishlist' => null,
    'showRating' => true,
    'showTitle' => true,
    'showCartButton' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $addedInCompareList = checkCompareList($product->id);
?>

<div class="product-card">
    <?php if(Route::is('wishlist.page')): ?>
        <button class="active removeWishlist wishlist-product-remove-btn" data-page="1" data-id="<?php echo e($wishlist->id); ?>" data-pid="<?php echo e($product->id); ?>"><i class="las la-trash"></i></button>
    <?php endif; ?>
    <div class="product-thumb">
        <ul class="product-card-buttons">
            <?php if(gs('product_wishlist')): ?>
                <li class="product-wishlist-btn">
                    <?php if(!Route::is('wishlist.page')): ?>
                        <button tyepe="button" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['addToWishlist', 'active' => checkWishList($product->id)]); ?>" data-id="<?php echo e($product->id); ?>"><i class="lar la-heart"></i></button>
                    <?php endif; ?>
                </li>
            <?php endif; ?>

            <?php if($product->product_type_id && gs('product_compare')): ?>
                <li class="product-compare-btn">
                    <button tyepe="button" class="addToCompare <?php echo e($addedInCompareList ? 'active' : ''); ?>" data-id="<?php echo e($product->id); ?>"><i class="las la-exchange-alt"></i></button>
                </li>
            <?php endif; ?>

            <?php if(!$showCartButton): ?>
                <?php if($product->productVariants->count()): ?>
                    <li class="product-quick-view-btn">
                        <button class="quickViewBtn" data-product="<?php echo e($product->slug); ?>"><i class="las la-cart-plus"></i></button>
                    </li>
                <?php else: ?>
                    <li class="product-quick-view-btn">
                        <input type="hidden" name="quantity" value="1">
                        <button tyepe="button" class="addToCart" data-id="<?php echo e($product->id); ?>" data-product_type="<?php echo e($product->product_type); ?>"><i class="las la-cart-plus"></i></button>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>

        <a href="<?php echo e($product->link()); ?>">
            <img src="<?php echo e(getImage(null)); ?>" class="lazyload" data-src="<?php echo e($product->mainImage()); ?>" alt="flash">
        </a>
    </div>

    <div class="product-content">
        <div class="product-before-content">
            <?php if($showTitle): ?>
                <h6 class="title">
                    <a data-src="<?php echo e($product->mainImage()); ?>"  href="<?php echo e($product->link()); ?>"><?php echo e(strLimit(__($product->name), 40)); ?></a>
                </h6>
            <?php endif; ?>

            <div class="single_content__info">
                <div class="price">
                    <?php
                        echo $product->formattedPrice();
                    ?>
                </div>

                <?php if($showRating && gs('product_review')): ?>
                    <div class="ratings-area">
                        <span class="ratings">
                            <?php echo displayRating($product->reviews_avg_rating) ?>
                        </span>
                        <span class="rating-count">(<?php echo e($product->reviews_count ?? 0); ?>)</span>
                    </div>
                <?php endif; ?>
            </div>

            <?php if($product->summary): ?>
                <div class="single_content">
                    <p><?php echo e(__($product->summary)); ?></p>
                </div>
            <?php endif; ?>
        </div>

        <?php if($showCartButton): ?>
            <?php if($product->productVariants->count()): ?>
                <button class="quickViewBtn add-to-cart-btn" data-product="<?php echo e($product->slug); ?>"><i class="las la-shopping-bag"></i> <?php echo app('translator')->get('Add to Cart'); ?></button>
            <?php else: ?>
                <input type="hidden" name="quantity" value="1">
                <button type="button" class="addToCart add-to-cart-btn" data-id="<?php echo e($product->id); ?>" data-product_type="<?php echo e($product->product_type); ?>"><i class="las la-shopping-bag"></i> <?php echo app('translator')->get('Add to Cart'); ?></button>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/components/frontend/basic/product-card.blade.php ENDPATH**/ ?>