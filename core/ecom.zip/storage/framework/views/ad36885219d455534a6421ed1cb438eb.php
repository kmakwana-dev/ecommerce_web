<?php
    $elements = getContent('services.element', orderById: true);
?>

<?php if($elements->count()): ?>
    <section class="py-60 service-section">
        <div class="container">
            <div class="services-wrapper">
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="services-card">
                        <div class="services-card__icon">
                            <img src="<?php echo e(getImage('assets/images/frontend/services/' . $element->data_values->image, '60x50')); ?>" alt="">
                        </div>
                        <div class="services-card__content">
                            <h5 class="services-card__text mb-1"><?php echo e(__($element->data_values->title)); ?></h5>
                            <span class="sub-title"><?php echo e(__($element->data_values->subtitle)); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true).'css/service-section.css')); ?>">
<?php $__env->stopPush(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/sections/services.blade.php ENDPATH**/ ?>