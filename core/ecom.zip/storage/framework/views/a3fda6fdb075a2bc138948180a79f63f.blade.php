<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['product'])
<x-frontend.basic.product-card :product="$product" >

{{ $slot ?? "" }}
</x-frontend.basic.product-card>