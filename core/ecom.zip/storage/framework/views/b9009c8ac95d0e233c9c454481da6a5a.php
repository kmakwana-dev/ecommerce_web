<?php
    $featuredCategories = \App\Models\Category::where('feature_in_banner', 1)->with('products.brand')->get();

    if (gs('homepage_layout') == 'sidebar_menu') {
        $categoriesToShow = [
            768 => ['items' => 5],
            992 => ['items' => 5],
            1199 => ['items' => 5],
        ];
        if (!$fixedBanner) {
            $categoriesToShow[1399] = ['items' => 6];
        }
    } else {
        $categoriesToShow = [
            768 => ['items' => 6],
            992 => ['items' => 7],
            1199 => ['items' => 9],
        ];
    }
?>

<?php if(!blank($featuredCategories)): ?>
    <div class="overflow-hidden">
        <div class="featured-category-slider owl-theme owl-carousel">
            <?php $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="banner-categories p-2">
                    <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => frontendComponent('category-card')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['category' => $category]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php $__env->startPush('script'); ?>
        <script>
            (function($) {
                "use strict";
                const categoriesToShow = <?php echo json_encode($categoriesToShow, 15, 512) ?>;

                const viewItems = {
                    0: {
                        items: 3,
                        margin: 12,
                    },
                    425: {
                        items: 4,
                        margin: 12,
                    },
                    575: {
                        items: 4,
                        margin: 12,
                    },
                    ...categoriesToShow
                };



                $(".featured-category-slider").owlCarousel({
                    margin: 16,
                    responsiveClass: true,
                    items: 3,
                    nav: false,
                    dots: false,
                    autoplay: true,
                    autoplayTimeout: 4000,
                    loop: true,
                    lazyLoad: true,
                    responsive: viewItems,
                });
            })(jQuery);
        </script>
    <?php $__env->stopPush(); ?>

<?php endif; ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/banner_categories.blade.php ENDPATH**/ ?>