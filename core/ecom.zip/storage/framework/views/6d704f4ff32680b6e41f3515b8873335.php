<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Template::sections.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if($sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(View::exists('Template::sections.' . $sec)): ?>
                <?php echo $__env->make('Template::sections.' . $sec, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <?php
                    $sectionData = getSectionData($sec, isFrontend: true);
                ?>

                <?php if($sectionData && array_key_exists('section', $sectionData)): ?>
                    <?php echo $__env->make($sectionData['section'], ['data' => @$sectionData['data']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset(activeTemplate(true) . 'css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset(activeTemplate(true) . 'css/product-details.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true) . 'css/xzoom/xzoom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true) . 'css/xzoom/magnific-popup.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/owl-carousel.js')); ?>"></script>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/xzoom/xzoom.min.js')); ?>"></script>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/xzoom/magnific-popup.js')); ?>"></script>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/xzoom/setup.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Template::layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/home.blade.php ENDPATH**/ ?>