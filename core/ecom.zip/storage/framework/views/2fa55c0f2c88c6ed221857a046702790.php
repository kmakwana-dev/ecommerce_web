<?php
    $headerThreeKeys = array_keys((array) $headerThree->group);

    $firstLetters = array_map(function ($key) {
        return $key[0];
    }, $headerThreeKeys);

    $layoutClass = 'primary-menu-' . implode('', $firstLetters);

    $headerColor = $headerThree?->background_color ?? gs('base_color');
?>

<?php if(@$headerThree->status == 'on'): ?>
    <div class="header-bottom <?php if(gs('homepage_layout') == 'full_width_banner'): ?> without-category <?php endif; ?>">
        <div class="container">
            <div class="row g-0">
                <div class="header-bottom-wrapper <?php echo e($layoutClass); ?>">

                    <button class="primary-menu-button d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>

                    <?php $__currentLoopData = $headerThree->group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == 'category_widget' && isset($group->status) && $group->status == 'on'): ?>
                            <div class="d-none d-lg-block view-category-wrapper">
                                <div class="view-category">
                                    <div class="menu-category-btn" <?php if(@$group->background_color): ?> style="background-color: <?php echo e('#' . $group->background_color); ?>" <?php endif; ?>>
                                        <?php if (isset($component)) { $__componentOriginal1a4f0e4508ec853ca1fde3ef9b482adb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a4f0e4508ec853ca1fde3ef9b482adb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.svg.category-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.category-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a4f0e4508ec853ca1fde3ef9b482adb)): ?>
<?php $attributes = $__attributesOriginal1a4f0e4508ec853ca1fde3ef9b482adb; ?>
<?php unset($__attributesOriginal1a4f0e4508ec853ca1fde3ef9b482adb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a4f0e4508ec853ca1fde3ef9b482adb)): ?>
<?php $component = $__componentOriginal1a4f0e4508ec853ca1fde3ef9b482adb; ?>
<?php unset($__componentOriginal1a4f0e4508ec853ca1fde3ef9b482adb); ?>
<?php endif; ?>
                                        <?php echo app('translator')->get('Categories'); ?>
                                    </div>
                                </div>

                                <div class="category-dropdown-menu">
                                    <?php echo $__env->make('Template::partials.left_category_menu', ['limit' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                            </div>
                        <?php elseif($key == 'links'): ?>
                            <?php echo $__env->make('Template::partials.menu.site_menu', [
                                'classes' => 'd-none d-lg-flex',
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endif; ?>

                        <?php if($key == 'widgets'): ?>
                            <div class="action-btn-inner d-flex">
                                <?php $__currentLoopData = collect($group)->where('status', 'on'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($widget->key == 'cart'): ?>
                                        <div class="cart-icon-design">
                                            <button class="button cart-button flex-shrink-0" <?php if(Route::is('cart.page')): echo 'disabled'; endif; ?> <?php if(@$widget->background_color): ?> style="background-color: <?php echo e('#' . $widget->background_color); ?> !important" <?php endif; ?>>
                                                <i class="las la-shopping-bag"></i>
                                                <span class="flex-shrink-0">
                                                    <span class="amount d-block"><?php echo e(gs('cur_sym')); ?><span class="cartSubtotal">0</span></span>
                                                    <span class="items d-block">(<span class="cartItemCount">0</span>) <?php echo app('translator')->get('items'); ?></span>
                                                </span>
                                            </button>
                                        </div>
                                    <?php elseif($widget->key == 'wishlist' && gs('product_wishlist')): ?>
                                        <div class="cart-icon-design widget--style" <?php if(@$widget->background_color): ?> style="background-color: <?php echo e('#' . @$widget->background_color); ?> !important" <?php endif; ?>>
                                            <button class="button wish-button" <?php if(Route::is('wishlist.page')): echo 'disabled'; endif; ?> id="wish-button">
                                                <span class="ico">
                                                    <i class="lar la-heart"></i>
                                                </span>
                                                <span class="wishlist-count ecommerce__is">0</span>
                                            </button>
                                        </div>
                                    <?php elseif($widget->key == 'compare' && gs('product_compare')): ?>
                                        <div class="cart-icon-design widget--style" <?php if(@$widget->background_color): ?> style="background-color: <?php echo e('#' . @$widget->background_color); ?> !important" <?php endif; ?>>
                                            <a href="<?php echo e(route('compare.all')); ?>">
                                                <span class="ico">
                                                    <i class="las la-exchange-alt"></i>
                                                </span>
                                                <span class="compare-count ecommerce__is">0</span>
                                            </a>
                                        </div>
                                    <?php elseif($widget->key == 'user_auth'): ?>
                                        <div class="h-100 d-flex align-items-center" <?php if(@$widget->background_color): ?> style="background-color: <?php echo e('#' . @$widget->background_color); ?> !important" <?php endif; ?>>
                                            <?php echo $__env->make('Template::partials.user_auth_options', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    <?php elseif($widget->key == 'language'): ?>
                                        <div class="h-100 d-flex align-items-center" <?php if(@$widget->background_color): ?> style="background-color: <?php echo e('#' . @$widget->background_color); ?> !important" <?php endif; ?>>
                                            <?php echo $__env->make('Template::partials.menu.language_menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    <?php elseif($widget->key == 'notifications'): ?>
                                        <div class="h-100 d-flex align-items-center" <?php if(@$widget->background_color): ?> style="background-color: <?php echo e('#' . @$widget->background_color); ?> !important" <?php endif; ?>>
                                            <?php if (isset($component)) { $__componentOriginalcd27c9b38e54bac77bc581449ce10798 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd27c9b38e54bac77bc581449ce10798 = $attributes; } ?>
<?php $component = App\View\Components\UserNotificationComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-notification-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\UserNotificationComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd27c9b38e54bac77bc581449ce10798)): ?>
<?php $attributes = $__attributesOriginalcd27c9b38e54bac77bc581449ce10798; ?>
<?php unset($__attributesOriginalcd27c9b38e54bac77bc581449ce10798); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd27c9b38e54bac77bc581449ce10798)): ?>
<?php $component = $__componentOriginalcd27c9b38e54bac77bc581449ce10798; ?>
<?php unset($__componentOriginalcd27c9b38e54bac77bc581449ce10798); ?>
<?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


<?php $__env->startPush('style'); ?>
    <style>
        .header-bottom {
            background-color: #<?php echo e($headerColor); ?>

        }

        .menu li a.active {
            background-color: #ffffff33;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/headers/header_three.blade.php ENDPATH**/ ?>