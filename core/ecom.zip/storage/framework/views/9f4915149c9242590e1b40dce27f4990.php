<?php
    $headerOne = App\Models\Frontend::where('data_keys', 'header_one.content')->first()?->data_values;
?>
<?php if($headerOne->status == 'on'): ?>

    <div class="header-top d-none d-md-block bg-white">
        <div class="container">
            <div class="header-top-wrap d-flex flex-wrap justify-content-between align-items-center">
                <?php if(@$headerOne->links_position == 'left'): ?>
                    <?php echo $__env->make('Template::partials.header_top_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('Template::partials.header_top_predefined_options', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('Template::partials.header_top_predefined_options', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('Template::partials.header_top_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/headers/header_one.blade.php ENDPATH**/ ?>