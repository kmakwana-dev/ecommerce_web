<?php $__env->startSection('app'); ?>
    <?php echo $__env->make('Template::partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if(!Route::is('cart.page')): ?>
        <div class="site-sidebar cart-sidebar-area" id="cart-sidebar-area">
            <button class="sidebar-close-btn"><i class="las la-times"></i></button>
            <div class="top-content d-flex gap-2">
                <h5 class="cart-sidebar-area__title"><?php echo app('translator')->get('My Cart'); ?></h5> <a href="<?php echo e(route('cart.page')); ?>" class="text-muted text-decoration-underline"><?php echo app('translator')->get('Cart Page'); ?></a>
            </div>
            <div class="cart-products cart--products"></div>
        </div>
    <?php endif; ?>

    <?php if(gs('product_wishlist')): ?>
        <div class="site-sidebar cart-sidebar-area wishlist-sidebar" id="wish-sidebar-area">
            <button class="sidebar-close-btn"><i class="las la-times"></i></button>
            <div class="top-content d-flex gap-2">
                <h5 class="cart-sidebar-area__title"><?php echo app('translator')->get('My Wishlist'); ?></h5> <a href="<?php echo e(route('wishlist.page')); ?>" class="text-muted text-decoration-underline"><?php echo app('translator')->get('Wishlist Page'); ?></a>
            </div>
            <div class="cart-products wish--products"></div>
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="site-sidebar sidebar-nav" id="authSidebarMenu">
            <button type="button" class="sidebar-close-btn"><i class="las la-times"></i></button>

            <ul class="text--white login-user-menu">
                <?php echo $__env->make('Template::user.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <a class="scrollToTop" href="javascript:void(0)"><i class="las la-angle-up"></i></a>
    <?php
        $cookie = App\Models\Frontend::where('data_keys', 'cookie.data')->first();
    ?>

    <?php if($cookie->data_values->status == Status::ENABLE && !\Cookie::get('gdpr_cookie')): ?>
        <div class="cookies-card text-center hide">
            <div class="cookies-card__icon bg--base">
                <i class="las la-cookie-bite"></i>
            </div>
            <p class="mt-4 cookies-card__content"><?php echo e($cookie->data_values->short_desc); ?> <a href="<?php echo e(route('cookie.policy')); ?>" target="_blank" class="text--base"><?php echo app('translator')->get('Learn more'); ?></a></p>
            <div class="cookies-card__btn mt-4">
                <a class="btn btn--base w-100 policy h-45" href="javascript:void(0)"><?php echo app('translator')->get('Allow'); ?></a>
            </div>
        </div>
    <?php endif; ?>

    <?php echo $__env->make('Template::partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(auth()->guard()->guest()): ?>
        <div class="modal custom--modal fade" id="loginModal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close modal-close-btn" data-bs-dismiss="modal" aria-label="Close">
                            <i class="las la-times"></i>
                        </button>

                        <?php echo $__env->make('Template::partials.login', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if(gs('guest_checkout')): ?>
        <?php if(auth()->guard()->guest()): ?>
            <?php echo $__env->make('Template::partials.guest_user_info', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            $(document).on('click', '.login-trigger', function() {
                $(".sidebar-close-btn").trigger('click');
            });

            $('.policy').on('click', function() {
                $.get("<?php echo e(route('cookie.accept')); ?>", function(response) {
                    $('.cookies-card').addClass('d-none');
                });
            });
        })(jQuery);
    </script>

    <?php if (isset($component)) { $__componentOriginal99a11b557ec3d9477e01db3f04772425 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99a11b557ec3d9477e01db3f04772425 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.whimsicraft-script','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.whimsicraft-script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99a11b557ec3d9477e01db3f04772425)): ?>
<?php $attributes = $__attributesOriginal99a11b557ec3d9477e01db3f04772425; ?>
<?php unset($__attributesOriginal99a11b557ec3d9477e01db3f04772425); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99a11b557ec3d9477e01db3f04772425)): ?>
<?php $component = $__componentOriginal99a11b557ec3d9477e01db3f04772425; ?>
<?php unset($__componentOriginal99a11b557ec3d9477e01db3f04772425); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <script src="<?php echo e(asset(activeTemplate(true) . 'js/lazyload.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Template::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/layouts/master.blade.php ENDPATH**/ ?>