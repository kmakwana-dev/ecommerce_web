<div class="overlay"></div>
<div class="preloader">
    <img src="<?php echo e(asset('assets/images/logo_icon/preloader.gif')); ?>" alt="preloader" width="100">
    <h6 class="preloader-title"><span><?php echo e(__(gs('preloader_title'))); ?></span></h6>
</div>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/preloader.blade.php ENDPATH**/ ?>