<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>

<?php if (isset($component)) { $__componentOriginald76f0b00f68c2dbe5d9aadc83c803ab2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald76f0b00f68c2dbe5d9aadc83c803ab2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.basic.empty-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.basic.empty-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald76f0b00f68c2dbe5d9aadc83c803ab2)): ?>
<?php $attributes = $__attributesOriginald76f0b00f68c2dbe5d9aadc83c803ab2; ?>
<?php unset($__attributesOriginald76f0b00f68c2dbe5d9aadc83c803ab2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald76f0b00f68c2dbe5d9aadc83c803ab2)): ?>
<?php $component = $__componentOriginald76f0b00f68c2dbe5d9aadc83c803ab2; ?>
<?php unset($__componentOriginald76f0b00f68c2dbe5d9aadc83c803ab2); ?>
<?php endif; ?><?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\storage\framework\views/d73e2114a80bc4b2f654a1fc37919b0f.blade.php ENDPATH**/ ?>