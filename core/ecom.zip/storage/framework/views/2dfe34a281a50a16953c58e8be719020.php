<div class="position-relative user-dropdown-wrapper">
    <button type="button" class="user-account <?php if(auth()->guard()->guest()): ?> login-btn <?php else: ?> user-dropdown-btn <?php endif; ?> button" <?php if(auth()->guard()->guest()): ?> data-bs-toggle="modal" data-bs-target="#loginModal" <?php endif; ?>>
        <span class="icon">
            <i class="las la-user"></i>
        </span>
        <?php if(auth()->guard()->check()): ?>
            <span><?php echo app('translator')->get('My Account'); ?> <span class="ms-1"><i class="la la-angle-down"></i></span> </span>
        <?php else: ?>
            <span><?php echo app('translator')->get('My Account'); ?></span>
        <?php endif; ?>
    </button>

    <?php if(auth()->guard()->check()): ?>
        <div class="before-dropdown-menu">
            <ul class="login-user-menu">
                <li>
                    <a href="<?php echo e(route('user.home')); ?>" class="<?php echo e(menuActive('user.home')); ?>"> <i class="las la-home"></i><?php echo app('translator')->get('Dashboard'); ?></a>
                </li>

                <li>
                    <a href="<?php echo e(route('user.orders.all')); ?>" class="<?php echo e(menuActive('user.orders')); ?>"><i class="las la-list"></i><?php echo app('translator')->get('Orders'); ?></a>
                </li>

                <li>
                    <a href="<?php echo e(route('user.profile.setting')); ?>" class="<?php echo e(menuActive('user.profile.setting')); ?>"><i class="las la-user-alt"></i><?php echo app('translator')->get('Profile'); ?></a>
                </li>

                <li>
                    <a href="<?php echo e(route('user.change.password')); ?>" class="<?php echo e(menuActive('user.change.password')); ?>"><i class="las la-key"></i><?php echo app('translator')->get('Change Password'); ?></a>
                </li>

                <li>
                    <a href="<?php echo e(route('user.logout')); ?>"><i class="la la-sign-out"></i><?php echo app('translator')->get('Sign Out'); ?></a>
                </li>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/user_auth_options.blade.php ENDPATH**/ ?>