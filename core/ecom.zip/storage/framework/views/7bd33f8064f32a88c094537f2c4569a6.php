<?php
    $content = getContent('login_page.content', true)->data_values;
    $idPrefix = isset($idPrefix) ? $idPrefix : '';

?>

<h5 class="modal-title mt-3"><?php echo e(@$content->heading); ?></h5>
<div class="login-wrapper">
    <form method="POST" action="<?php echo e(route('user.login')); ?>" class="sign-in-form">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label class="form--label" for="<?php echo e($idPrefix); ?>login-username"><?php echo app('translator')->get('Username'); ?></label>
            <input type="text" class="form--control" name="username" id="<?php echo e($idPrefix); ?>login-username" value="<?php echo e(old('email')); ?>">
        </div>

        <div class="form-group">
            <label class="form--label" for="<?php echo e($idPrefix); ?>login-password"><?php echo app('translator')->get('Password'); ?></label>
            <input type="password" class="form--control" name="password" id="<?php echo e($idPrefix); ?>login-password">
        </div>

        <div class="form-group">
            <div class="d-flex gap-1 flex-wrap justify-content-between">

                <div class="form-check form--check d-flex gap-1 align-items-center mb-0">
                    <label class="form-check-label m-0 lh-1 d-flex align-items-center">
                        <input class="form-check-input me-1" type="checkbox" name="remember" id="<?php echo e($idPrefix); ?>remember-me"><?php echo app('translator')->get('Remember Me'); ?>
                    </label>
                </div>

                <a href="<?php echo e(route('user.password.request')); ?>"
                    class="t-link d-block text-end text--base heading-clr sm-text fw-md">
                    <?php echo app('translator')->get('Forgot Password?'); ?>
                </a>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginalff0a9fdc5428085522b49c68070c11d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff0a9fdc5428085522b49c68070c11d6 = $attributes; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Captcha::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $attributes = $__attributesOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__attributesOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $component = $__componentOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__componentOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>

        <button type="submit" class="btn btn--base w-100 h-45"><?php echo app('translator')->get('Login'); ?></button>

        <p class="create-accounts mb-0 mt-2">
            <span class="text-dark">
                <?php echo app('translator')->get('Don\'t have an account?'); ?> <a href="<?php echo e(route('user.register')); ?>" class="text--base"><?php echo app('translator')->get('Create An Account'); ?></a>
            </span>
        </p>
    </form>

    <?php echo $__env->make('Template::partials.social_login', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<?php $__env->startPush('style'); ?>
    <style>
        .form--check .form-check-input {
            margin-top: 1px !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/login.blade.php ENDPATH**/ ?>