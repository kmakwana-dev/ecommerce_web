<ul class="menu <?php echo e(@$classes); ?>">
    <?php $__currentLoopData = $siteMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(url($menu->url)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'active' => url($menu->url) == request()->url() && $menu->url != '/',
        ]); ?>"><?php echo e(__($menu->name)); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/menu/site_menu.blade.php ENDPATH**/ ?>