<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal35c5002ce6bcfa3c8d46efa76143cfa2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35c5002ce6bcfa3c8d46efa76143cfa2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.basic.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.basic.product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35c5002ce6bcfa3c8d46efa76143cfa2)): ?>
<?php $attributes = $__attributesOriginal35c5002ce6bcfa3c8d46efa76143cfa2; ?>
<?php unset($__attributesOriginal35c5002ce6bcfa3c8d46efa76143cfa2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35c5002ce6bcfa3c8d46efa76143cfa2)): ?>
<?php $component = $__componentOriginal35c5002ce6bcfa3c8d46efa76143cfa2; ?>
<?php unset($__componentOriginal35c5002ce6bcfa3c8d46efa76143cfa2); ?>
<?php endif; ?><?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\storage\framework\views/a3fda6fdb075a2bc138948180a79f63f.blade.php ENDPATH**/ ?>