<?php
    $sliders = getContent('banner.element');
?>

<?php if(!blank($sliders)): ?>
    <div class="slider-wrapper overflow-hidden rounded--5">
        <div class="banner-slider owl-theme owl-carousel">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slide-item">
                    <a href="<?php echo e(@$slider->data_values->link); ?>" class="d-block">
                        <img src="<?php echo e(frontendImage('banner', @$slider->data_values->slider, '990x480')); ?>" alt="slider-image">
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>


<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            $(".banner-slider").owlCarousel({
                items: 1,
                loop: true,
                autoplay: 1,
                nav: false,
                dots: false,
                animateOut: 'fadeOut'
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/templates/basic/partials/banner_sliders.blade.php ENDPATH**/ ?>