<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'message' => null,
    'isTable' => false,
    'showMessage' => true,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'message' => null,
    'isTable' => false,
    'showMessage' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($isTable): ?>
    <div class="empty-message-card">
        <div class="empty-thumb">
            <img src="<?php echo e(asset('assets/images/empty_list.png')); ?>" alt="image">
        </div>
        <?php if($showMessage): ?>
            <p class="text-center text-muted"><?php echo e(__($message ?? $emptyMessage)); ?></p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="empty-message text-center">
        <img src="<?php echo e(getImage('assets/images/empty.png')); ?>" class="lazyload" alt="">
        <?php if($showMessage): ?>
            <h6 class="message mt-2"><?php echo e(__($message ?? $emptyMessage)); ?></h6>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\NovaFin\Ecommerce_Web\visermart-ecommerce-shopping-platform\Files\core\resources\views/components/frontend/basic/empty-message.blade.php ENDPATH**/ ?>